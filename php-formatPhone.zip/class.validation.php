<?php
/*!
 * DB HOST: localhost
 * DB USER: root
 * DB PASS: hell
 */
 
class Validation {
	//! Put all your processing methods in this class
	
/*
	public function ...() {
		
	}
*/


}
?>